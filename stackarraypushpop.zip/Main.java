class Stack {
    int a[];
    int top;
    int capacity;
    int t;

    
    Stack(int size) {
        this.capacity = size;
        this.a = new int[capacity];
        this.top = -1; 
    }

    public void push(int value) {
        if (top == capacity - 1) {
            System.out.println("overflow " + value);
        } else {
            a[++top] = value;
            System.out.println( "pushed value ="+value );
        }
        System.out.println();
    }
public void pop(){
    if(top==-1){
   
       }
    else{
       t=a[top];
        top--;
        System.out.println("poped value ="+t);
    }
    System.out.println();
    }
public void peak(){
    if(top==-1){
        
    }else{
        System.out.println("peak value = "+a[top]);
    }
    System.out.println();
}

    public void display() {
        if (top == -1) {
            System.out.println("Stack is empty.");
        } else {
             for (int i = 0; i <= top; i++) {
                 System.out.print(+a[i] + " ");
            }
            System.out.println();
        }
    }
}
public class Main{
    public static void main(String[] args) {
        Stack s = new Stack(5); 
       s.push(10);
        s.push(20);
        s.push(30);
        s.push(40);
        s.push(50);
        s.pop();
        s.push(60); 
        s.pop();
        s.peak();
        s.display(); 
    }
}
